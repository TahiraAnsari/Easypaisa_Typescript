#! /usr/bin/env node

import inquirer from "inquirer";
import chalk from "chalk";

console.log(chalk.bgCyan.bold("************Welcome to Easy Paisa************"));
console.log("************************************************");
console.log(chalk.bgGreen.bold("************My PINCode is 12345************"));

let myBalance = 15000;
const myPin = 12345;
let condition = true;

let answers = await inquirer.prompt([
    {
        name: "pincode",
        type: "number",
        message: (chalk.blueBright("Enter your 5 Digit Pincode"))
    }
]);

if(answers.pincode === myPin){
    console.log(chalk.green("CORRECT PINCODE"));

    do{
        let operationAns = await inquirer.prompt([
            {
                name: "operation",
                type: "list",
                message: (chalk.blueBright("Select an Operation")),
                choices: ["Check Balance", "Withdraw", "Transfer Money", "Deposit", "Bills Payment", "Easy Load Bundle", "Exit"]
            }
        ]);
        if(operationAns.operation === "Check Balance"){
            console.log(chalk.yellowBright(myBalance));
            
        }
        else if(operationAns.operation === "Withdraw"){
            let withdrawAns = await inquirer.prompt([
                {
                    name: "amount",
                    type: "number",
                    message: (chalk.blueBright("Enter the amount you want to Withdraw"))
                }
            ]);
            if(withdrawAns.amount <= myBalance){
                let WDbalance = myBalance - withdrawAns.amount;
                console.log(chalk.yellowBright("Your remaining Balance is " + WDbalance));
            }
            else{
                console.log(chalk.red("Insufficient Balance"));
            }
        }
        else if(operationAns.operation === "Transfer Money"){
            let transferAns = await inquirer.prompt([
                {
                    name: "amount",
                    type: "number",
                    message: (chalk.blueBright("Enter the amountr you want to Transfer"))
                }
            ]);
            if(transferAns.amount <= myBalance){
                let Tbalance = myBalance - transferAns.amount;
                console.log(chalk.yellowBright("Your remaining balance is " + Tbalance));
            }else{
                console.log(chalk.red("Insufficient Balance"));
            }
        }
        else if(operationAns.operation === "Deposit"){
            let depositAns = await inquirer.prompt([
                {
                    name: "amount",
                    type: "number",
                    message: (chalk.blueBright("Enter the amount you want to deposit"))
                }
            ]);
            let Dbalance = myBalance + depositAns.amount;
            console.log(chalk.yellowBright("Your current balance is "+ Dbalance));
        }
        else if(operationAns.operation === "Bills Payment"){
            let billPaymentsAns = await inquirer.prompt([
                {
                    name: "amount",
                    type: "number",
                    message: (chalk.blueBright("Enter the amount you want to pay"))
                }
            ]);
            if(billPaymentsAns.amount <= myBalance){
                let BPbalance = myBalance - billPaymentsAns.amount;
                console.log(chalk.yellowBright("Your remaining balance is "+ BPbalance));
            }else{
                console.log(chalk.red("Insufficient Balance"));
            }
        }
        else if(operationAns.operation === "Easy Load Bundle"){
            let easyloadBundle = await inquirer.prompt([
                {
                    name: "amount",
                    type: "list",
                    message: (chalk.blueBright("Enter the amount")),
                    choices: ["100", "200", "300", "500", "1000"]
                },
                {
                    name: "phoneNumber",
                    type: "number",
                    message: (chalk.blueBright("Enter your phone number"))
                }
            ]);
            if(easyloadBundle.amount <= myBalance){
                console.log(chalk.greenBright("Load successfully Done"));
                let ELBbalance = myBalance - easyloadBundle.amount;
                console.log(chalk.yellowBright("Your remaining Balance is " + ELBbalance));    
            }
            else{
                console.log(chalk.red("Insufficient Balance"));
            }
        }
        else if(operationAns.operation === "Exit"){
            console.log(chalk.gray("Exiting"));
            console.log(chalk.green.italic("Thank You for using EASY PAISA SERVICE"));
            process.exit(0);
        }
    }while(condition);
}else{
    console.log(chalk.redBright("INCORRECT PINCODE"));
    
}


